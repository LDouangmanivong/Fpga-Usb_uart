﻿using System;
using System.IO.Ports;
using System.Text;

namespace SerialPortExample
{
    class SerialPortProgram
    {
        // Create the serial port with basic settings
        private SerialPort portA = new SerialPort("COM6",
          115200, Parity.None, 8, StopBits.One);

        private SerialPort portB = new SerialPort("COM8",
          115200, Parity.None, 8, StopBits.One);

        int tmpA;
        int tmpB;
        byte[] bytestosendA = new byte[1];
        byte[] bytestosendB = new byte[1];
        

        [STAThread]
        static void Main(string[] args)
        {
            // Instatiate this class
            new SerialPortProgram();
        }

        private SerialPortProgram()
        {

            // Begin communications
            portA.Open();
            portB.Open();

            // Enter an application loop to keep this thread alive
            while (true)
            {
                //read from A and send to B
                //Console.Write("Data A: ");
                tmpA = portA.ReadByte();
                tmpB = portB.ReadByte();
                var dataA = BitConverter.GetBytes(tmpA);
                var dataB = BitConverter.GetBytes(tmpB);

                portB.Write(dataA, 0, bytestosendA.Length);
                portA.Write(dataB, 0, bytestosendB.Length);

            }//end while
        }

    }
}